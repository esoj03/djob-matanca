﻿const products = [];

// Controller para renderizar a página de adição de produto
exports.getAddProduct = (req, res, next) => {
  res.render("add-product", {
    pageTitle: "Add Product",
    path: "/admin/add-product",
    formsCSS: true,
    productCSS: true,
    activeAddProduct: true,
  });
};

// Controller para lidar com a submissão do formulário de adição de produto
exports.postAddProduto = (req, res, next) => {
  const title = req.body.title;
    // Adicione o novo produto à lista de produtos
    products.push({ title: title }); // Adicione outros detalhes do produto conforme necessário
    res.redirect('/');
};

// Controller para exibir os produtos na área de administração
exports.getAdminProducts = (req, res, next) => {
  // Neste ponto, você pode adicionar a lógica para renderizar uma página
  // com a lista de produtos e opções de gerenciamento (editar, excluir, etc.)
  // Por enquanto, vamos apenas enviar uma mensagem de sucesso.
  res.status(200).send("Admin Products");
};
