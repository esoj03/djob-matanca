const express = require('express');
const router = express.Router();

const adminController = require('../controllers/Cadmin');

// Rota para adicionar um novo produto
router.get('/add-product', adminController.getAddProduct);
router.post('/add-product', adminController.postAddProduto);

// Rota para gerenciar produtos
router.get('/products', adminController.getAdminProducts);

module.exports = router;


